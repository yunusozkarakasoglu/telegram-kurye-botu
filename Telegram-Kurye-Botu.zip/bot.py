import argparse
import hmac
import json
import logging
import re
import secrets
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

TURKIYE = timezone(timedelta(hours=3))
PAYMENTS = ("Nakit", "Kart", "Ödendi")
DEFAULT_ACTIVE_LIMIT = 3
DEFAULT_TARIFF = (120, 30, 40, 50, 60, 70, 80, 90, 100)
TARIFF_BOUNDS = (3, 4, 5, 6, 7, 8, 9, 10)
PERIODS = {1: "Bugün", 7: "Son 7 Gün", 30: "Son 30 Gün"}
REPORT_PERIODS = {**PERIODS, 0: "Tüm Zamanlar"}

ROOT = Path(__file__).resolve().parent
MENUS = {
    "restoran": ["Kurye Çağır", "Paketlerim", "Analiz"],
    "kurye": ["Açık Paketler", "Paketlerim"],
    "yonetici": ["Açık Paketler", "Son Talepler", "Paket Limiti", "Ücret Tarifesi", "Sipariş Verilerini Temizle", "Kurye Durumu"],
}


def connect(path):
    db = sqlite3.connect(path, timeout=15)
    db.row_factory = sqlite3.Row
    db.executescript("""
        PRAGMA foreign_keys = ON;
        CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY, role TEXT NOT NULL, name TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS invites (
            code TEXT PRIMARY KEY, role TEXT NOT NULL, name TEXT NOT NULL, expires INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS drafts (
            owner INTEGER PRIMARY KEY REFERENCES accounts, nonce TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0, regions TEXT NOT NULL DEFAULT '[]'
        );
        CREATE TABLE IF NOT EXISTS batches (
            id INTEGER PRIMARY KEY, owner INTEGER NOT NULL REFERENCES accounts
        );
        CREATE TABLE IF NOT EXISTS packages (
            id INTEGER PRIMARY KEY, batch INTEGER NOT NULL REFERENCES batches, number INTEGER NOT NULL,
            region TEXT NOT NULL, courier INTEGER REFERENCES accounts, UNIQUE(batch, number)
        );
        CREATE TABLE IF NOT EXISTS outbox (
            id INTEGER PRIMARY KEY, method TEXT NOT NULL, payload TEXT NOT NULL,
            package INTEGER REFERENCES packages
        );
        CREATE TABLE IF NOT EXISTS cards (
            package INTEGER NOT NULL REFERENCES packages, chat INTEGER NOT NULL,
            message INTEGER NOT NULL, PRIMARY KEY (chat, message)
        );
        CREATE TABLE IF NOT EXISTS tariff (
            position INTEGER PRIMARY KEY, amount INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS pending_distance (
            courier INTEGER PRIMARY KEY REFERENCES accounts, package INTEGER NOT NULL REFERENCES packages
        );
        CREATE TABLE IF NOT EXISTS reset_confirmation (
            admin INTEGER PRIMARY KEY REFERENCES accounts, token TEXT NOT NULL, expires INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS checkpoint (id INTEGER PRIMARY KEY CHECK(id=1), offset INTEGER);
        INSERT OR IGNORE INTO checkpoint VALUES (1, 0);
    """)
    with db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("INSERT OR IGNORE INTO settings VALUES ('active_limit',?)", (DEFAULT_ACTIVE_LIMIT,))
        db.executemany("INSERT OR IGNORE INTO tariff VALUES (?,?)", enumerate(DEFAULT_TARIFF))
        columns = {
            "outbox": {"order_related": "INTEGER NOT NULL DEFAULT 0"},
            "accounts": {"locked": "INTEGER NOT NULL DEFAULT 0", "online": "INTEGER NOT NULL DEFAULT 0"},
            "drafts": {"payments": "TEXT NOT NULL DEFAULT '[]'"},
            "batches": {"created_at": "INTEGER"},
            "packages": {
                "payment": "TEXT", "accepted_at": "INTEGER",
                "picked_up_at": "INTEGER", "delivered_at": "INTEGER",
                "distance_km": "TEXT", "courier_fee": "INTEGER",
            },
        }
        for table, additions in columns.items():
            existing = {row["name"] for row in db.execute(f"PRAGMA table_info({table})")}
            for name, declaration in additions.items():
                if name not in existing:
                    db.execute(f"ALTER TABLE {table} ADD COLUMN {name} {declaration}")
                    if table == "drafts":
                        db.execute("DELETE FROM drafts")
                    if name == "locked":
                        db.execute("""
                            UPDATE accounts SET locked=1 WHERE role='kurye' AND
                            (SELECT count(*) FROM packages WHERE courier=accounts.id) >= ?
                        """, (DEFAULT_ACTIVE_LIMIT,))
        db.execute("CREATE INDEX IF NOT EXISTS packages_by_courier ON packages(courier, delivered_at)")
    return db


class APIError(Exception):
    def __init__(self, code, delay=None):
        self.code = code
        self.delay = delay
        super().__init__(f"Telegram HTTP/API {code}")


class Telegram:
    def __init__(self, token):
        self.base = f"https://api.telegram.org/bot{token}/"

    def call(self, method, **data):
        request = Request(self.base + method, json.dumps(data).encode(),
                          {"Content-Type": "application/json"})
        try:
            with urlopen(request, timeout=35) as response:
                result = json.load(response)
        except HTTPError as exc:
            try:
                result = json.load(exc)
            except ValueError:
                raise APIError(exc.code) from None
        except (URLError, TimeoutError):
            raise APIError(0) from None
        if not result["ok"]:
            raise APIError(result["error_code"], result.get("parameters", {}).get("retry_after"))
        return result["result"]


def keyboard(rows):
    return {"inline_keyboard": [
        [{"text": label, "callback_data": key} for label, key in row] for row in rows
    ]}


class Bot:
    def __init__(self, db, api, config, username="test_bot"):
        self.db = db
        self.api = api
        self.config = config
        self.username = username

    def queue(self, method, payload, package=None):
        self.db.execute("INSERT INTO outbox(method,payload,package) VALUES (?,?,?)",
                        (method, json.dumps(payload), package))

    def send(self, chat, text, markup=None, package=None):
        payload = {"chat_id": chat, "text": text}
        if markup is not None:
            payload["reply_markup"] = markup
        self.queue("sendMessage", payload, package)

    def menu(self, user, text):
        labels = [*MENUS[user["role"]], "Raporlar"]
        if user["role"] == "kurye":
            labels.append("Çevrimdışı Ol" if user["online"] else "Çevrimiçi Ol")
        self.send(user["id"], text, {
            "keyboard": [[{"text": label} for label in labels[i:i + 2]] for i in range(0, len(labels), 2)],
            "resize_keyboard": True,
        })

    def process(self, update):
        callback = update.get("callback_query")
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            offset = self.db.execute("SELECT offset FROM checkpoint").fetchone()[0]
            if update["update_id"] < offset:
                return
            message = callback.get("message", {}) if callback else update.get("message", {})
            if message.get("chat", {}).get("type") == "private":
                sender = callback["from"]["id"] if callback else message["from"]["id"]
                user = self.db.execute("SELECT * FROM accounts WHERE id=?", (sender,)).fetchone()
                if callback:
                    data = callback.get("data", "")
                    if data.split(":", 1)[0] == "reset":
                        answer = self.action(user, data)
                    else:
                        with self.order_messages():
                            answer = self.action(user, data)
                    self.queue("answerCallbackQuery", {
                        "callback_query_id": callback["id"], "text": answer or "Tamam",
                    })
                elif "text" in message:
                    text = message["text"].strip()
                    command = text.split(" ", 1)[0]
                    if (text in ("Kurye Çağır", "Açık Paketler", "Paketlerim", "Raporlar", "Analiz", "Son Talepler")
                            or command in ("/rapor", "/mesafe", "/mesafeiptal")
                            or re.match(r"^[0-9+.,-]", text)):
                        with self.order_messages():
                            self.message(sender, user, text)
                    else:
                        self.message(sender, user, text)
            self.db.execute("UPDATE checkpoint SET offset=? WHERE id=1", (update["update_id"] + 1,))

    @contextmanager
    def order_messages(self):
        last_id = self.db.execute("SELECT coalesce(max(id),0) FROM outbox").fetchone()[0]
        yield
        self.db.execute("UPDATE outbox SET order_related=1 WHERE id>?", (last_id,))

    def message(self, chat, user, text):
        command, _, args = text.partition(" ")
        if not user:
            if (command == "/yonetici" and args and
                    hmac.compare_digest(args.encode(), self.config["admin_code"].encode()) and
                    not self.db.execute("SELECT 1 FROM accounts WHERE role='yonetici'").fetchone()):
                self.db.execute("INSERT INTO accounts(id,role,name) VALUES (?,?,?)", (chat, "yonetici", "Yönetici"))
            elif command == "/start" and args:
                invite = self.db.execute("DELETE FROM invites WHERE code=? AND expires>? RETURNING role,name",
                                         (args, int(time.time()))).fetchone()
                if invite:
                    self.db.execute("INSERT INTO accounts(id,role,name) VALUES (?,?,?)", (chat, *invite))
            user = self.db.execute("SELECT * FROM accounts WHERE id=?", (chat,)).fetchone()
            if not user:
                self.send(chat, "Kayıt için yöneticinizden geçerli bir davet bağlantısı isteyin.")
                return
        if command in ("/start", "/yonetici"):
            self.menu(user, f"Hoş geldiniz, {user['name']}.")
        elif user["role"] == "yonetici" and (text == "Paket Limiti" or command == "/limit"):
            self.configure_limit(chat, args.strip())
        elif user["role"] == "yonetici" and (text == "Ücret Tarifesi" or command == "/tarife"):
            self.configure_tariff(chat, args)
        elif user["role"] == "kurye" and (command == "/mesafe" or re.match(r"^[0-9+.,-]", text)):
            self.record_distance(chat, args if command == "/mesafe" else text)
        elif user["role"] == "kurye" and command == "/mesafeiptal":
            self.db.execute("DELETE FROM pending_distance WHERE courier=?", (chat,))
            self.send(chat, "Kilometre girişi iptal edildi. Paketinizden tekrar başlatabilirsiniz.")
        elif command == "/davet" and user["role"] == "yonetici":
            role, _, name = args.strip().partition(" ")
            name = name.strip()
            if role not in ("restoran", "kurye") or not 1 <= len(name) <= 80:
                self.send(chat, "Kullanım\n/davet restoran Ertaş Döner\n/davet kurye Ahmet Yılmaz")
                return
            code = secrets.token_urlsafe(24)
            self.db.execute("INSERT INTO invites VALUES (?,?,?,?)",
                            (code, role, name, int(time.time()) + 86400))
            self.send(chat, f"{name} için davet\nhttps://t.me/{self.username}?start={code}")
        elif text == "Kurye Çağır" and user["role"] == "restoran":
            nonce = secrets.token_hex(6)
            self.db.execute("INSERT OR REPLACE INTO drafts(owner,nonce) VALUES (?,?)", (chat, nonce))
            buttons = [(str(n), f"count:{nonce}:{n}") for n in range(1, 11)]
            self.send(chat, "Kaç paket göndereceksiniz?", keyboard([buttons[:5], buttons[5:]]))
        elif user["role"] == "kurye" and text in ("Çevrimiçi Ol", "Çevrimdışı Ol"):
            self.set_courier_status(chat, text == "Çevrimiçi Ol")
        elif text == "Kurye Durumu" and user["role"] == "yonetici":
            self.show_courier_status(chat, 0)
        elif text == "Açık Paketler" and user["role"] in ("kurye", "yonetici"):
            self.show_open(user, 0)
        elif text == "Paketlerim" and user["role"] in ("kurye", "restoran"):
            if user["role"] == "kurye":
                self.send(chat, "Paket listenizi seçin.", keyboard([
                    [("Aktif Paketler", "page:active:0"), ("Teslim Geçmişi", "page:delivered:0")]
                ]))
            else:
                self.show_mine(user, 0)
        elif text == "Sipariş Verilerini Temizle" and user["role"] == "yonetici":
            self.confirm_order_reset(chat)
        elif text == "Raporlar" or command == "/rapor":
            self.send(chat, "Sipariş raporu için dönem seçin.", keyboard([
                [(label, f"report:{days}:0")] for days, label in REPORT_PERIODS.items()
            ]))
        elif text == "Analiz" and user["role"] == "restoran":
            self.send(chat, "Talep tarihine göre dönem seçin.", keyboard([
                [(label, f"analysis:{days}:0")] for days, label in PERIODS.items()
            ]))
        elif text == "Son Talepler" and user["role"] == "yonetici":
            self.show_packages(user, "1", (), 0, "recent")
        else:
            self.menu(user, "Menüden bir işlem seçin.")

    def confirm_order_reset(self, admin):
        token = secrets.token_urlsafe(12)
        self.db.execute("INSERT OR REPLACE INTO reset_confirmation VALUES (?,?,?)",
                        (admin, token, int(time.time()) + 300))
        count = self.db.execute("SELECT count(*) FROM packages").fetchone()[0]
        self.send(admin, (
            f"{count} paket ve tüm sipariş taslakları kalıcı olarak silinecek. "
            "Kurye ve restoran hesapları ile ayarlar korunacak."
        ), keyboard([[("Siparişleri Sil", f"reset:yes:{token}"), ("Vazgeç", f"reset:no:{token}")]]))

    def reset_orders(self, admin, decision, token):
        if decision not in ("yes", "no"):
            return "Geçersiz işlem."
        consumed = self.db.execute("""
            DELETE FROM reset_confirmation WHERE admin=? AND token=? AND expires>?
        """, (admin, token, int(time.time())))
        if not consumed.rowcount:
            return "Onay geçersiz veya süresi doldu."
        if decision == "no":
            return "İptal edildi."
        for table in ("batches", "packages"):
            last_used = self.db.execute(f"SELECT coalesce(max(id),0) FROM {table}").fetchone()[0]
            self.db.execute("""
                INSERT INTO settings VALUES (?,?)
                ON CONFLICT(key) DO UPDATE SET value=max(value,excluded.value)
            """, (f"{table}_id_floor", last_used))
        self.db.execute("DELETE FROM pending_distance")
        self.db.execute("DELETE FROM drafts")
        self.db.execute("DELETE FROM outbox WHERE package IS NOT NULL OR order_related=1")
        self.db.execute("DELETE FROM cards")
        deleted = self.db.execute("DELETE FROM packages").rowcount
        self.db.execute("DELETE FROM batches")
        self.db.execute("UPDATE accounts SET locked=0 WHERE role='kurye' AND locked<>0")
        self.send(admin, f"Sipariş verileri temizlendi. {deleted} paket silindi.")
        return "Siparişler silindi."

    def next_order_id(self, table):
        return self.db.execute(f"""
            SELECT max(coalesce((SELECT max(id) FROM {table}),0),
                       coalesce((SELECT value FROM settings WHERE key=?),0)) + 1
        """, (f"{table}_id_floor",)).fetchone()[0]

    def tariff(self):
        return tuple(row[0] for row in self.db.execute("SELECT amount FROM tariff ORDER BY position"))

    def configure_tariff(self, chat, args):
        if args.strip():
            values = args.split()
            if len(values) != 9 or any(not re.fullmatch(r"[0-9]{1,6}", value) for value in values):
                self.send(chat, "Taban ücret ve 8 kademe farkını tam TL olarak girin. Örnek: /tarife 120 30 40 50 60 70 80 90 100")
                return
            self.db.executemany("UPDATE tariff SET amount=? WHERE position=?",
                                [(int(value), position) for position, value in enumerate(values)])
        tariff = self.tariff()
        intervals = ["0–3", ">3–4", ">4–5", ">5–6", ">6–7", ">7–8", ">8–9", ">9–10", ">10"]
        amounts = "\n".join(f"{interval} km · {sum(tariff[:position + 1])} TL"
                            for position, interval in enumerate(intervals))
        command = "/tarife " + " ".join(map(str, tariff))
        self.send(chat, f"Güncel ücret tarifesi\n{amounts}\n\nDüzenlemek için komutu kopyalayın:\n{command}")

    def record_distance(self, courier, value):
        pending = self.db.execute("SELECT package FROM pending_distance WHERE courier=?", (courier,)).fetchone()
        if not pending:
            self.send(courier, "Kilometre girmek için pakette Restorandan Aldım düğmesine basın.")
            return
        match = re.fullmatch(r"([0-9]{1,5}(?:[.,][0-9]{1,3})?)(?:\s*km)?", value.strip(), re.IGNORECASE)
        if not match:
            self.send(courier, "Geçerli bir kilometre girin. Örnek: 4,5")
            return
        distance = Decimal(match[1].replace(",", "."))
        tariff = self.tariff()
        fee = tariff[0] + sum(extra for boundary, extra in zip(TARIFF_BOUNDS, tariff[1:]) if distance > boundary)
        package_id = pending["package"]
        updated = self.db.execute("""
            UPDATE packages SET picked_up_at=?,distance_km=?,courier_fee=?
            WHERE id=? AND courier=? AND picked_up_at IS NULL AND delivered_at IS NULL
        """, (int(time.time()), format(distance.normalize(), "f"), fee, package_id, courier))
        self.db.execute("DELETE FROM pending_distance WHERE courier=?", (courier,))
        if not updated.rowcount:
            self.send(courier, "Bu paketin kilometre girişi artık açık değil.")
            return
        package = self.packages("p.id=?", (package_id,))[0]
        self.card(courier, package, "kurye")

    def active_limit(self):
        return self.db.execute("SELECT value FROM settings WHERE key='active_limit'").fetchone()[0]

    def configure_limit(self, chat, value):
        current = self.active_limit()
        if not value:
            self.send(chat, f"Genel paket limiti · {current}\nDeğiştirmek için /limit 5 yazın.")
            return
        if not value.isascii() or not value.isdecimal() or len(value) > 2 or not 1 <= int(value) <= 99:
            self.send(chat, "1 ile 99 arasında bir paket limiti girin. Örnek: /limit 5")
            return
        limit = int(value)
        self.db.execute("UPDATE settings SET value=? WHERE key='active_limit'", (limit,))
        couriers = self.db.execute("""
            SELECT a.id FROM accounts a JOIN packages p ON p.courier=a.id
            WHERE a.role='kurye' AND a.locked=0 AND p.delivered_at IS NULL
            GROUP BY a.id HAVING count(*) >= ?
        """, (limit,)).fetchall()
        for courier in couriers:
            self.lock_courier(courier["id"], limit)
        self.send(chat, f"Genel paket limiti tüm kuryeler için {limit} olarak ayarlandı.")

    def lock_courier(self, courier, limit):
        self.db.execute("UPDATE accounts SET locked=1 WHERE id=?", (courier,))
        self.db.execute("""
            DELETE FROM outbox WHERE package IS NOT NULL AND json_extract(payload,'$.chat_id')=?
        """, (courier,))
        self.send(courier, f"{limit} aktif paket sınırına ulaştınız. Yeni iş için üzerinizdeki tüm paketleri teslim edin.")

    def set_courier_status(self, courier, online):
        self.db.execute("UPDATE accounts SET online=? WHERE id=? AND role='kurye'", (online, courier))
        if not online:
            self.db.execute("""
                DELETE FROM outbox WHERE package IS NOT NULL AND json_extract(payload,'$.chat_id')=?
            """, (courier,))
        user = self.db.execute("SELECT * FROM accounts WHERE id=?", (courier,)).fetchone()
        text = "Çevrimiçisiniz." if online else "Çevrimdışısınız. Yeni paket bildirimi almayacaksınız."
        if online and user["locked"]:
            text += " Yeni iş için üzerinizdeki tüm paketleri teslim edin."
        elif online:
            text += " Bekleyen işleri Açık Paketler menüsünden görebilirsiniz."
        self.menu(user, text)

    def show_courier_status(self, admin, page):
        summary = self.db.execute("""
            SELECT count(*) AS total, count(*) FILTER (WHERE online=1) AS online,
                   count(*) FILTER (WHERE online=1 AND locked=0) AS available,
                   count(*) FILTER (WHERE EXISTS (
                       SELECT 1 FROM packages WHERE courier=accounts.id AND delivered_at IS NULL
                   )) AS working
            FROM accounts WHERE role='kurye'
        """).fetchone()
        rows = self.db.execute("""
            SELECT a.name,a.online,a.locked,
                   (SELECT count(*) FROM packages WHERE courier=a.id AND delivered_at IS NULL) AS active
            FROM accounts a WHERE a.role='kurye'
            ORDER BY a.online DESC,a.locked,a.name,a.id LIMIT 13 OFFSET ?
        """, (page * 12,)).fetchall()
        lines = [
            "Kurye Durumu",
            f"Toplam {summary['total']} · Çevrimiçi {summary['online']} · Çevrimdışı {summary['total'] - summary['online']}",
            f"Yeni işe müsait {summary['available']} · Aktif paketi olan {summary['working']}",
            "",
        ]
        for row in rows[:12]:
            state = "Çevrimdışı" if not row["online"] else "Teslim kilidi" if row["locked"] else "Müsait"
            lines.append(f"{row['name']} · {state} · {row['active']} aktif paket")
        if not rows:
            lines.append("Bu sayfada kurye yok.")
        buttons = []
        if page > 0:
            buttons.append(("Önceki", f"couriers:{page - 1}"))
        if len(rows) > 12:
            buttons.append(("Sonraki", f"couriers:{page + 1}"))
        self.send(admin, "\n".join(lines), keyboard([buttons]) if buttons else None)

    def show_open(self, user, page):
        if user["role"] == "kurye" and not user["online"]:
            self.send(user["id"], "Açık paketleri görmek için çevrimiçi olun.")
            return
        if user["role"] == "kurye" and user["locked"]:
            self.send(user["id"], "Yeni işler için üzerinizdeki tüm paketleri teslim edin.")
            return
        self.show_packages(user, "p.courier IS NULL", (), page, "open")

    def analysis(self, user, days, page):
        start = datetime.now(TURKIYE).replace(hour=0, minute=0, second=0, microsecond=0)
        start -= timedelta(days=days - 1)
        params = (user["id"], int(start.timestamp()))
        counts = self.db.execute("""
            SELECT count(*) AS total,
                   count(*) FILTER (WHERE p.courier IS NULL) AS waiting,
                   count(*) FILTER (WHERE p.courier IS NOT NULL AND p.delivered_at IS NULL) AS active,
                   count(p.delivered_at) AS delivered
            FROM packages p JOIN batches b ON p.batch=b.id
            WHERE b.owner=? AND b.created_at>=?
        """, params).fetchone()
        self.send(user["id"], (
            f"{PERIODS[days]} · {start:%d.%m.%Y} itibarıyla oluşturulan paketler\n"
            f"Toplam {counts['total']} · Bekliyor {counts['waiting']} · "
            f"Kurye üzerinde {counts['active']} · Teslim edildi {counts['delivered']}"
        ))
        self.show_packages(user, "b.owner=? AND b.created_at>=?", params, page, f"analysis:{days}")

    def order_report(self, user, days, page):
        role = user["role"]
        date_field = "p.accepted_at" if role == "kurye" else "b.created_at"
        date_label = "Kabul" if role == "kurye" else "Talep"
        where = "1"
        params = ()
        if role == "kurye":
            where, params = "p.courier=?", (user["id"],)
        elif role == "restoran":
            where, params = "b.owner=?", (user["id"],)
        if days:
            today = datetime.now(TURKIYE).replace(hour=0, minute=0, second=0, microsecond=0)
            start = today - timedelta(days=days - 1)
            where += f" AND {date_field}>=? AND {date_field}<?"
            params += (int(start.timestamp()), int((today + timedelta(days=1)).timestamp()))
        page_size = 6
        rows = self.packages(where, (*params, page_size * page), f"LIMIT {page_size + 1} OFFSET ?")
        header = f"Sipariş Raporu · {REPORT_PERIODS[days]} · Sayfa {page + 1}"
        entries = []
        for row in rows[:page_size]:
            date = row["accepted_at"] if role == "kurye" else row["created_at"]
            formatted_date = datetime.fromtimestamp(date, TURKIYE).strftime("%d.%m.%Y %H:%M:%S") if date is not None else "—"
            distance = row["distance_km"]
            distance = f"{distance.replace('.', ',')} km" if distance is not None else "—"
            fields = [f"Talep #{row['batch']} · Paket {row['number']}", f"{date_label} · {formatted_date}"]
            if role != "restoran":
                fields.append(f"Restoran · {row['restaurant']}")
            fields.append(f"Bölge · {row['region']}")
            if role != "kurye":
                fields.append(f"Kurye · {row['courier_name'] or '—'}")
            fields.append(f"Mesafe · {distance}")
            fee = f"{row['courier_fee']} TL" if row["courier_fee"] is not None else "—"
            fields.append(f"Kurye ücreti · {fee}")
            fields.append(f"Durum · {self.status(row)}")
            entries.append("\n".join(fields))
        buttons = []
        if page:
            buttons.append(("Önceki", f"report:{days}:{page - 1}"))
        if len(rows) > page_size:
            buttons.append(("Sonraki", f"report:{days}:{page + 1}"))
        body = "\n\n".join(entries) if entries else "Bu dönemde raporlanacak paket yok."
        self.send(user["id"], f"{header}\n\n{body}", keyboard([buttons]) if buttons else None)

    def show_mine(self, user, page):
        self.show_packages(user, "b.owner=?", (user["id"],), page, "mine")

    def packages(self, where, params=(), suffix=""):
        return self.db.execute("""
            SELECT p.*, b.owner, b.created_at, r.name AS restaurant, c.name AS courier_name
            FROM packages p JOIN batches b ON b.id=p.batch
            JOIN accounts r ON r.id=b.owner LEFT JOIN accounts c ON c.id=p.courier
            WHERE """ + where + " ORDER BY p.id DESC " + suffix, params).fetchall()

    @staticmethod
    def label(package):
        return (f"Talep #{package['batch']} · Paket {package['number']}\n"
                f"{package['restaurant']} · {package['region']}\n"
                f"Ödeme · {package['payment'] or 'Belirtilmedi'}")

    @staticmethod
    def status(package):
        if package["delivered_at"]:
            return "Teslim Edildi"
        if package["picked_up_at"]:
            return "Restorandan Alındı"
        return "Kabul Edildi" if package["courier"] else "Bekliyor"

    def details(self, package, show_fee=False):
        lines = [self.label(package), self.status(package)]
        if package["courier"]:
            lines[-1] += f" · {package['courier_name']}"
        for key, label in (("accepted_at", "Kabul"), ("picked_up_at", "Alım"), ("delivered_at", "Teslim")):
            if package[key] is not None:
                stamp = datetime.fromtimestamp(package[key], TURKIYE)
                lines.append(f"{label} · {stamp:%d.%m.%Y %H:%M:%S}")
        if show_fee and package["courier_fee"] is not None:
            distance = package["distance_km"].replace(".", ",")
            lines.extend((f"Mesafe · {distance} km", f"Kurye ücreti · {package['courier_fee']} TL"))
        return "\n".join(lines)

    def delivery_markup(self, package):
        if package["delivered_at"]:
            return keyboard([])
        action, label = ("deliver", "Teslim Ettim") if package["picked_up_at"] else ("pickup", "Restorandan Aldım")
        return keyboard([[(label, f"{action}:{package['id']}")]])

    def card(self, chat, package, role):
        package_id = package["id"]
        if package["courier"]:
            markup = self.delivery_markup(package) if role == "kurye" and chat == package["courier"] else None
            self.send(chat, self.details(package, show_fee=role in ("kurye", "yonetici")), markup)
        elif role in ("kurye", "yonetici"):
            label_button = "Kabul Et" if role == "kurye" else "Kurye Seç"
            action = "claim" if role == "kurye" else "assign"
            self.send(chat, self.details(package), keyboard([[(label_button, f"{action}:{package_id}")]]), package_id)
        else:
            self.send(chat, self.details(package))

    def show_packages(self, user, where, params, page, mode):
        rows = self.packages(where, (*params, page * 8), "LIMIT 9 OFFSET ?")
        for row in rows[:8]:
            self.card(user["id"], row, user["role"])
        if not rows:
            self.send(user["id"], "Bu listede paket yok.")
        prefix = mode if mode.startswith("analysis:") else f"page:{mode}"
        navigation = []
        if page:
            navigation.append(("Önceki", f"{prefix}:{page - 1}"))
        if len(rows) > 8:
            navigation.append(("Sonraki", f"{prefix}:{page + 1}"))
        if navigation:
            self.send(user["id"], f"Sayfa {page + 1}", keyboard([navigation]))

    def action(self, user, data):
        if not user:
            return "Bu işlem için kayıt gerekli."
        role, chat = user["role"], user["id"]
        action, *args = data.split(":")
        if action == "couriers" and role == "yonetici" and len(args) == 1 and re.fullmatch(r"[0-9]{1,9}", args[0]):
            self.show_courier_status(chat, int(args[0]))
            return
        if action == "reset" and role == "yonetici" and len(args) == 2:
            return self.reset_orders(chat, *args)
        if action in ("count", "region", "payment", "send", "cancel") and role == "restoran":
            return self.draft_action(chat, action, args)
        if action == "page" and len(args) == 2 and args[1].isdigit():
            mode, page = args[0], int(args[1])
            if role == "kurye" and mode in ("active", "delivered"):
                condition = "IS NULL" if mode == "active" else "IS NOT NULL"
                self.show_packages(user, f"p.courier=? AND p.delivered_at {condition}", (chat,), page, mode)
                return
            if mode == "mine" and role == "restoran":
                self.show_mine(user, page)
                return
            if mode == "open" and role in ("kurye", "yonetici"):
                self.show_open(user, page)
                return
            if mode == "recent" and role == "yonetici":
                self.show_packages(user, "1", (), page, mode)
                return
        if action == "report" and len(args) == 2 and all(re.fullmatch(r"[0-9]{1,9}", arg) for arg in args):
            days, page = map(int, args)
            if days in REPORT_PERIODS:
                self.order_report(user, days, page)
                return
        if action == "analysis" and role == "restoran" and len(args) == 2 and all(x.isdigit() for x in args):
            days, page = map(int, args)
            if days in PERIODS:
                self.analysis(user, days, page)
                return
        if action in ("pickup", "deliver") and role == "kurye" and len(args) == 1 and args[0].isdigit():
            return self.advance(int(args[0]), chat, action)
        if action == "claim" and role == "kurye" and len(args) == 1 and args[0].isdigit():
            return self.claim(int(args[0]), chat, False)
        if action == "assign" and role == "yonetici" and len(args) in (1, 2) and all(x.isdigit() for x in args):
            return self.choose_courier(chat, int(args[0]), int(args[1]) if len(args) == 2 else 0)
        if action == "give" and role == "yonetici" and len(args) == 2 and all(x.isdigit() for x in args):
            return self.claim(int(args[0]), int(args[1]), True)
        return "Bu işlem kullanılamıyor."

    def draft_action(self, chat, action, args):
        draft = self.db.execute("SELECT * FROM drafts WHERE owner=?", (chat,)).fetchone()
        if not args or not draft or args[0] != draft["nonce"]:
            return "Bu talep artık etkin değil."
        nonce = draft["nonce"]
        selected = json.loads(draft["regions"])
        payments = json.loads(draft["payments"])
        quantity = draft["quantity"]
        regions = self.config["regions"]
        if action == "cancel":
            self.db.execute("DELETE FROM drafts WHERE owner=?", (chat,))
            self.send(chat, "Talep iptal edildi.")
            return
        if action == "count" and quantity == 0 and len(args) == 2 and args[1].isdigit():
            quantity = int(args[1])
            if not 1 <= quantity <= 10:
                return "Geçersiz paket adedi."
            self.db.execute("UPDATE drafts SET quantity=? WHERE owner=?", (quantity, chat))
        elif action == "region" and len(args) == 3 and all(x.isdigit() for x in args[1:]):
            step, index = map(int, args[1:])
            if step != len(selected) or step != len(payments) or step >= quantity or index >= len(regions):
                return "Bu bölge seçimi artık etkin değil."
            selected.append(regions[index])
            self.db.execute("UPDATE drafts SET regions=? WHERE owner=?", (json.dumps(selected), chat))
        elif action == "payment" and len(args) == 3 and all(x.isdigit() for x in args[1:]):
            step, index = map(int, args[1:])
            if step != len(payments) or len(selected) != step + 1 or index >= len(PAYMENTS):
                return "Bu ödeme seçimi artık etkin değil."
            payments.append(PAYMENTS[index])
            self.db.execute("UPDATE drafts SET payments=? WHERE owner=?", (json.dumps(payments), chat))
        elif action == "send" and quantity and len(selected) == len(payments) == quantity:
            self.submit(chat, selected, payments)
            return "Talep gönderildi."
        else:
            return "Bu adım artık etkin değil."
        cancel = [("İptal Et", f"cancel:{nonce}")]
        if len(selected) > len(payments):
            buttons = [(label, f"payment:{nonce}:{len(payments)}:{i}") for i, label in enumerate(PAYMENTS)]
            self.send(chat, f"Paket {len(selected)}/{quantity} · {selected[-1]}\nÖdeme tipini seçin.",
                      keyboard([buttons, cancel]))
        elif len(selected) < quantity:
            buttons = [(region, f"region:{nonce}:{len(selected)}:{i}") for i, region in enumerate(regions)]
            rows = [buttons[i:i + 2] for i in range(0, len(buttons), 2)]
            self.send(chat, f"Paket {len(selected) + 1}/{quantity} için teslimat bölgesini seçin.",
                      keyboard([*rows, cancel]))
        else:
            preview = "\n".join(f"Paket {i} · {region} · {payment}"
                                for i, (region, payment) in enumerate(zip(selected, payments), 1))
            self.send(chat, preview, keyboard([[("Talebi Gönder", f"send:{nonce}")], cancel]))

    def submit(self, chat, selected, payments):
        batch = self.next_order_id("batches")
        first_package = self.next_order_id("packages")
        self.db.execute("INSERT INTO batches(id,owner,created_at) VALUES (?,?,?)",
                        (batch, chat, int(time.time())))
        self.db.executemany("INSERT INTO packages(id,batch,number,region,payment) VALUES (?,?,?,?,?)",
                            [(first_package + index, batch, index + 1, region, payment)
                             for index, (region, payment) in enumerate(zip(selected, payments))])
        self.db.execute("DELETE FROM drafts WHERE owner=?", (chat,))
        couriers = self.db.execute("SELECT id FROM accounts WHERE role='kurye' AND online=1 AND locked=0").fetchall()
        for package in reversed(self.packages("p.batch=?", (batch,))):
            for courier in couriers:
                self.card(courier["id"], package, "kurye")
        self.send(chat, f"Talep #{batch} oluşturuldu. {len(selected)} paket bekliyor.")

    def choose_courier(self, chat, package_id, page):
        if not self.packages("p.id=? AND p.courier IS NULL", (package_id,)):
            return "Bu paket artık açık değil."
        couriers = self.db.execute(
            "SELECT * FROM accounts WHERE role='kurye' AND online=1 AND locked=0 ORDER BY name,id LIMIT 11 OFFSET ?",
            (10 * page,),
        ).fetchall()
        if not couriers:
            return "Bu sayfada uygun kurye yok."
        buttons = [[(courier["name"], f"give:{package_id}:{courier['id']}")] for courier in couriers[:10]]
        navigation = []
        if page:
            navigation.append(("Önceki", f"assign:{package_id}:{page - 1}"))
        if len(couriers) > 10:
            navigation.append(("Sonraki", f"assign:{package_id}:{page + 1}"))
        if navigation:
            buttons.append(navigation)
        self.send(chat, "Atanacak kuryeyi seçin.", keyboard(buttons))

    def claim(self, package_id, courier, manual):
        account = self.db.execute("SELECT name,locked,online FROM accounts WHERE id=? AND role='kurye'", (courier,)).fetchone()
        if not account:
            return "Kurye bulunamadı."
        if not account["online"]:
            return "Kurye çevrimdışı. Yeni paket alamaz."
        if account["locked"]:
            return "Kurye, üzerindeki tüm paketleri teslim edene kadar yeni paket alamaz."
        updated = self.db.execute("UPDATE packages SET courier=?,accepted_at=? WHERE id=? AND courier IS NULL",
                                  (courier, int(time.time()), package_id))
        if updated.rowcount != 1:
            return "Bu paket alındı veya bulunamadı."
        limit = self.active_limit()
        if self.active_count(courier) >= limit:
            self.lock_courier(courier, limit)
        package = self.packages("p.id=?", (package_id,))[0]
        status = f"{account['name']} atandı." if manual else f"{account['name']} tarafından kabul edildi."
        label = self.label(package)
        self.send(package["owner"], f"{label}\n{status}")
        self.card(courier, package, "kurye")
        for card in self.db.execute("SELECT * FROM cards WHERE package=?", (package_id,)):
            self.queue("editMessageText", {
                "chat_id": card["chat"], "message_id": card["message"],
                "text": self.details(package),
                "reply_markup": keyboard([]),
            })
        return "Paket atandı."

    def active_count(self, courier):
        return self.db.execute(
            "SELECT count(*) FROM packages WHERE courier=? AND delivered_at IS NULL", (courier,)
        ).fetchone()[0]

    def advance(self, package_id, courier, action):
        rows = self.packages("p.id=? AND p.courier=?", (package_id, courier))
        if not rows:
            return "Bu paket size ait değil."
        package = rows[0]
        if package["delivered_at"]:
            return "Bu paket zaten teslim edildi."
        now = int(time.time())
        if action == "pickup":
            if package["picked_up_at"]:
                return "Paket zaten restorandan alındı."
            pending = self.db.execute("SELECT package FROM pending_distance WHERE courier=?", (courier,)).fetchone()
            if pending and pending["package"] != package_id:
                return "Önce diğer paketin kilometresini girin veya /mesafeiptal yazın."
            self.db.execute("INSERT OR IGNORE INTO pending_distance VALUES (?,?)", (courier, package_id))
            self.send(courier, f"{self.label(package)}\nRestorandan teslimat noktasına mesafeyi km olarak girin. Örnek: 4,5")
            return "Kilometre bekleniyor."
        else:
            if not package["picked_up_at"]:
                return "Önce paketi restorandan aldığınızı işaretleyin."
            self.db.execute("UPDATE packages SET delivered_at=? WHERE id=?", (now, package_id))
        package = self.packages("p.id=?", (package_id,))[0]
        self.card(courier, package, "kurye")
        if action == "deliver":
            self.send(package["owner"], self.details(package))
            if self.active_count(courier) == 0:
                unlocked = self.db.execute("UPDATE accounts SET locked=0 WHERE id=? AND locked=1", (courier,))
                if unlocked.rowcount:
                    user = self.db.execute("SELECT online FROM accounts WHERE id=?", (courier,)).fetchone()
                    if user["online"]:
                        self.send(courier, "Üzerinizdeki paketlerin tamamı teslim edildi. Yeni iş alabilirsiniz.",
                                  keyboard([[("Açık Paketler", "page:open:0")]]))
                    else:
                        self.send(courier, "Üzerinizdeki paketlerin tamamı teslim edildi. Yeni iş için çevrimiçi olun.")
        return self.status(package)

    def drain(self):
        for _ in range(30):
            row = self.db.execute("""SELECT * FROM outbox
                ORDER BY (method='answerCallbackQuery') DESC, id LIMIT 1""").fetchone()
            if not row:
                return False
            payload = json.loads(row["payload"])
            if row["package"] is not None:
                package = self.packages("p.id=?", (row["package"],))[0]
                locked = self.db.execute("SELECT locked,online FROM accounts WHERE id=? AND role='kurye'",
                                         (payload["chat_id"],)).fetchone()
                if locked and (locked["locked"] or not locked["online"]):
                    with self.db:
                        self.db.execute("DELETE FROM outbox WHERE id=?", (row["id"],))
                    continue
                if package["courier"]:
                    payload["text"] = self.details(package)
                    payload.pop("reply_markup", None)
            try:
                result = self.api.call(row["method"], **payload)
            except APIError as exc:
                if exc.code not in (400, 403):
                    raise
                logging.warning("Telegram iletisi gönderilemedi. İşlem %s, kod %s", row["method"], exc.code)
                result = None
            with self.db:
                if result and row["package"] is not None and "reply_markup" in payload:
                    self.db.execute("INSERT OR IGNORE INTO cards VALUES (?,?,?)",
                                    (row["package"], payload["chat_id"], result["message_id"]))
                self.db.execute("DELETE FROM outbox WHERE id=?", (row["id"],))
        return True


def main():
    parser = argparse.ArgumentParser(description="Telegram kurye botu")
    parser.add_argument("--ayarlar", type=Path, default=ROOT / "ayarlar.json")
    parser.add_argument("--veritabani", type=Path, default=ROOT / "kurye.sqlite3")
    args = parser.parse_args()
    config = json.loads(args.ayarlar.read_text(encoding="utf-8"))
    if (not config.get("token") or len(config.get("admin_code", "")) < 20
            or not 1 <= len(config.get("regions", [])) <= 50
            or any(not isinstance(region, str) or not 1 <= len(region.strip()) <= 50
                   for region in config["regions"])):
        parser.error("Bot anahtarı, en az 20 karakterli yönetici kodu ve 1–50 geçerli bölge girin.")
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    api = Telegram(config["token"])
    try:
        username = api.call("getMe")["username"]
    except APIError as exc:
        parser.exit(1, f"Telegram bağlantısı kurulamadı ({exc.code}).\n")
    db = connect(args.veritabani)
    bot = Bot(db, api, config, username)
    logging.info("@%s çalışıyor.", username)
    try:
        while True:
            try:
                pending = bot.drain()
                offset = db.execute("SELECT offset FROM checkpoint").fetchone()[0]
                updates = api.call("getUpdates", offset=offset, timeout=0 if pending else 20,
                                   allowed_updates=["message", "callback_query"])
                for update in updates:
                    bot.process(update)
            except APIError as exc:
                if exc.code == 409:
                    parser.exit(1, "Bot için başka bir süreç veya webhook etkin.\n")
                logging.warning("%s. Yeniden deneniyor.", exc)
                time.sleep(exc.delay or 3)
    except KeyboardInterrupt:
        logging.info("Bot durduruldu.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
