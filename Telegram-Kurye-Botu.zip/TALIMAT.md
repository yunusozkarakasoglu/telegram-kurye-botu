# Telegram Kurye Botu — İş Akışı ve Kurulum Planı

## Hedef

Restoran, bir talepte birden fazla paket açar. Her paket için teslimat bölgesi ve ödeme tipi girilir. Kuryeler açık paketleri ayrı ayrı kabul eder. Restoran, her kabul ve teslimatta bildirim alır. Genel paket limitine ulaşan kurye, üzerindeki tüm paketleri teslim edince yeniden iş alabilir.

## Roller ve iş akışı

| Rol | İşlemler |
|---|---|
| Yönetici (Yunus) | Restoran ve kurye daveti oluşturur, tüm talepleri izler, genel paket limitini değiştirir ve uygun kuryeye elle paket atar. |
| Restoran | 1–10 paket için bölge ve ödeme tipini tek tek seçer. Özeti onaylayıp tek talep gönderir. Kendi paketlerinin durumunu ve dönem özetini görür. |
| Kurye | Açık paketleri görür, paket kabul eder, restorandan aldığını ve teslim ettiğini işaretler. Kabul ve teslim geçmişini görüntüler. |

### Özellik kontrol listesi

| Alan | Botta bulunan özellikler |
|---|---|
| Hesap ve erişim | Yönetici, restoran ve kurye rolleri. Restoran ve kuryeler için tek kullanımlık davet. Aynı telefondaki iki Telegram hesabıyla yönetici ve kurye olarak çalışma. |
| Restoran | Bir talepte 1–10 paket. Her pakete ayrı bölge ve ödeme tipi. Gönderim öncesi özet. Kabul ve teslim bildirimleri. Kendi paketleri, analiz ve sipariş raporu. |
| Kurye | Çevrimiçi ve çevrimdışı çalışma durumu. Müsaitken yeni paket bildirimi, açık paket listesi ve paket bazında kabul. Aktif paketler, teslim geçmişi ve kendi sipariş raporu. |
| Teslimat | İlk geçerli kabul tek kuryeye atanır. Kurye paketi aldığında km girer, otomatik ücreti görür ve teslimi işaretler. Kabul ve teslim saatleri kaydedilir. |
| Kapasite | Tüm kuryeler için ortak, yönetici tarafından değiştirilebilir limit. Varsayılan üç. Sınıra ulaşan kurye tüm aktif paketlerini teslim edince tekrar iş alabilir. |
| Ücret | Yönetici taban ücreti ve kilometre kademe farklarını düzenler. Kaydedilmiş ücret pakette korunur. Restoran ücreti kendi raporunda görür. |
| Raporlar | Bugün, son 7 gün, son 30 gün ve tüm zamanlar. Yönetici tüm paketleri, restoran kendi taleplerini, kurye kendi atamalarını görür. |
| Yönetim | Kurye durumu ve aktif paket sayıları, açık paketler, elle atama, son talepler, limit ve tarife ayarları, onaylı sipariş verisi temizliği. |

### Kurye çalışma durumu

- Yeni ve mevcut kurye hesapları bu özellik ilk devreye alındığında çevrimdışı başlar. Kurye **Çevrimiçi Ol** veya **Çevrimdışı Ol** düğmesine basar. Durum yeniden başlatmada korunur.
- Çevrimdışı kurye yeni sipariş bildirimi almaz. Açık paket listesi, eski kabul düğmeleri ve yönetici ataması kapalıdır. Kendi mevcut paketlerinin alımını ve teslimini tamamlayabilir.
- Çevrimiçi ve teslim kilidi olmayan kurye yeni iş alabilir. Çevrimiçi olduğunda mevcut bekleyen işleri **Açık Paketler** menüsünden görür.
- Yönetici **Kurye Durumu** ekranında çevrimiçi, çevrimdışı, yeni işe müsait ve aktif paketi bulunan kurye sayılarını görür. İsim listesinde her kuryenin durumu ve üzerindeki aktif paket sayısı bulunur. Aktif paket sayımı çevrimdışı kuryelerin üzerindeki işleri de kapsar.

### Paket akışı

1. Restoran **Kurye Çağır** menüsünden paket adedini seçer.
2. Bot her paket için sırasıyla bölgeyi ve ödeme tipini sorar. Ödeme seçenekleri **Nakit**, **Kart** ve **Ödendi**. Ödeme tipi bilgi olarak kaydedilir.
3. Restoran paketleri özet listeden kontrol eder ve **Talebi Gönder** düğmesine basar.
4. Bot her paketi uygun kuryelere ayrı kart olarak gönderir. Paket başına yalnızca ilk geçerli kabul kaydedilir. Restoran, kurye adıyla bildirim alır.
5. Atanan kurye **Restorandan Aldım** düğmesine basar, paketin kilometresini girip hesaplanan ücreti görür. Teslimattan sonra **Teslim Ettim** düğmesine basar. Restorana teslim bildirimi gider.
6. **Paketlerim** ekranında kurye kabul ve teslim zamanını görür. **Analiz** ekranında restoran bugün, son 7 gün veya son 30 gün için paketlerini ve durum adetlerini görür. Bu ekran paketlerin oluşturulma tarihine göre çalışır. Saatler Türkiye saatidir.

### Sipariş raporları

Her rol **Raporlar** menüsünden bugün, son 7 gün, son 30 gün veya tüm zamanları seçebilir. Rapor paket bazında ve sayfalı olarak Telegram sohbetinde açılır.

| Rol | Kapsam | Alanlar |
|---|---|---|
| Yönetici | Tüm paketler | Talep tarihi ve saati, restoran, bölge, kurye, km, kurye ücreti, durum |
| Kurye | Kendisine atanmış paketler | Kabul tarihi ve saati, restoran, bölge, km, kendi ücreti, durum |
| Restoran | Kendi gönderdiği paketler | Talep tarihi ve saati, bölge, kurye, km, kurye ücreti, durum |

Saatler Türkiye saatidir. Raporlar kayıtlı paketlerden otomatik hazırlanır. Kurye ücretini yönetici, atanan kurye ve talebi açan restoran görür. Tarihi bilinmeyen eski kayıtlar **Tüm Zamanlar** raporunda yer alır.

### Sipariş verilerini temizleme

Yönetici menüsünden **Sipariş Verilerini Temizle → Siparişleri Sil** seçilir. Onay beş dakika geçerlidir. Aktif ve teslim edilmiş paketler, taslaklar, kilometre ve ücret kayıtları silinir. Kurye kilitleri açılır. Yönetici, kurye ve restoran hesapları, davetler, paket limiti ve tarife korunur. Telegram sohbetlerinde daha önce gönderilmiş mesajlar kalabilir. Eski sipariş düğmeleri yeni paketleri etkileyemez.

### Kurye ücreti ve yönetici tarifesi

- Kurye restoran ile teslimat noktası arasındaki mesafeyi her paket için ayrı girer. Örnek: `4,5`. Ücret kurye kartında ve üç rolün yetkili olduğu raporlarda görünür. Restoran ücreti yalnızca kendi raporunda görür.
- Yönetici **Ücret Tarifesi** menüsünden yürürlükteki tarifeyi görür. Taban ücret ve sekiz kademenin farklarını tam TL olarak değiştirmek için ekrandaki komutu kopyalar. Varsayılan komut: `/tarife 120 30 40 50 60 70 80 90 100`.
- Kademe üst sınırı dahildir. Varsayılan toplamlar: 0–3 km 120 TL, 3 üstü–4 km 150 TL, 4 üstü–5 km 190 TL, 5 üstü–6 km 240 TL, 6 üstü–7 km 300 TL, 7 üstü–8 km 370 TL, 8 üstü–9 km 450 TL, 9 üstü–10 km 540 TL, 10 km üstü 640 TL.
- Ücret, kilometre kaydedildiği andaki tarife ile hesaplanır. Sonradan yapılan tarife değişiklikleri kaydedilmiş ücretleri etkilemez.

### Tüm kuryeler için ortak paket limiti

- Varsayılan limit 3’tür. Yönetici **Paket Limiti** menüsünden mevcut değeri görür ve `/limit 5` gibi bir komutla değiştirir. Ayar, her kuryeye aynı şekilde uygulanır ve veritabanında saklanır.
- Limit, her kuryenin kendi aktif paket sayısına uygulanır. Aktif paketler **Kabul Edildi** ve **Restorandan Alındı** durumlarını kapsar.
- Sınıra ulaşan kurye yeni paket bildirimi almaz, açık paket listesini göremez ve eski düğmelerden paket kabul edemez. Yönetici de bu kuryeye paket atayamaz. Üzerindeki son paket teslim edilince kilit kalkar.
- Limit düşürülürse yeni sınıra ulaşmış kuryeler hemen kilitlenir. Mevcut paketler kuryede kalır. Limit yükseltilirse hâlihazırda kilitli kuryeler, aktif paketlerinin tamamını teslim edince yeniden iş alabilir.

## Kurulum ve pilot planı

1. [BotFather](https://t.me/BotFather) üzerinden `/newbot` ile Telegram botunu oluştur.
2. Python 3.11 veya üstünü kullan. `ayarlar.example.json` dosyasını `ayarlar.json` adıyla kopyala. Bot anahtarını `token` alanına, çalışma bölgelerini `regions` alanına yaz. Yönetici kodunu `python -c "import secrets; print(secrets.token_urlsafe(24))"` ile üretip `admin_code` alanına yaz. Ayar dosyasını ve kodu özel tut.
3. `python bot.py` komutuyla çalıştır. Yönetici olarak kendi Telegram hesabından botu aç ve özel sohbette `/yonetici KOD` yaz. Bu komut ilk yönetici hesabını bağlar. Mevcut veritabanıyla güncellemede kayıtlı yönetici korunur.
4. Yönetici hesabından `/davet restoran Ertaş Döner` ve `/davet kurye Ahmet Yılmaz` komutlarıyla tek kullanımlık davetler oluştur. Bağlantıları ilgili kişilere ilet. Bağlantılar 24 saat geçerlidir.
5. Bir restoran ve iki kurye ile pilot yap. Kuryeleri önce çevrimiçi yap. Bir kuryeyi çevrimdışı alıp bildirim, kabul ve yönetici ataması engelini ve mevcut teslimatın sürdüğünü kontrol et. Üç farklı ödeme tipiyle üç paket gönder. İki kurye aynı paketi kabul etmeyi denesin. Ardından bir kurye üç aktif pakete ulaşsın. Dördüncü paketin bildirimi, eski düğmeden kabulü ve yönetici ataması engellenmeli. İlk iki teslimden sonra kilit sürmeli. Üçüncü teslimden sonra açık işler görünmeli. Kurye geçmişini ve restoran analizini kontrol et.
6. Pilot tamamlanınca botu HTTPS çıkışı olan, sürekli çalışan bir sunucuda tek süreç olarak çalıştır. `kurye.sqlite3` dosyasını kalıcı diskte tut. Önceki sürümden geçişte botu durdur ve veritabanını yedekle. Gönderilmemiş form taslakları yükseltmede sıfırlanır. Eski paketlerde kaydedilmemiş ödeme tipi ve zaman alanları boş görünür.

[Telegram Bot API](https://core.telegram.org/bots/api)
